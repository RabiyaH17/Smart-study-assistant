"""StudyBuddy AI — source package."""
